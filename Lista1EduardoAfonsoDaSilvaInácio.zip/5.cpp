#include <GL/glut.h>
#include <math.h>
 
double theta;
float angulo = 1.0;
const int lados = 35;


void criarCirculo(const double raio){
	glBegin(GL_POLYGON);
	for (int a = 0; a<360; a += 360/lados){
		theta = a * 3.1415926535897932384626433832795 / 180;
		glVertex2d(cos(theta)*raio,sin(theta)*raio);
	}
	glEnd();
}

void rotacionarCirculo(void){
	glClear(GL_COLOR_BUFFER_BIT);
    glColor3f(0,0,1.0);
    glMatrixMode(GL_MODELVIEW);
    glRotatef(-angulo,0,0,1.0);
    criarCirculo(10.0);
    glColor3f(0,1.0,0);
    glRotatef(-angulo,0,0,1.0);
    criarCirculo(5.0);
    glutSwapBuffers();

}
 
 
void window(GLsizei w, GLsizei h){
        GLsizei largura, altura;
        if(h==0)h=1;
       
        largura = w;
        altura = h;
       
        glViewport(0,0,largura,altura);
       
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
       
        if(largura <=altura){
                gluOrtho2D(-20,20,-20*altura/largura,20*altura/largura);
        }else{
                gluOrtho2D(-20*largura/altura, 20*largura/altura, -20,20);
        }
}
 
int main(void){
        glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
        glutInitWindowSize(450,450);
        glutCreateWindow("CIRCULOMULTICORROTACAO");
        glutDisplayFunc(rotacionarCirculo);
        glutIdleFunc(rotacionarCirculo);
        glutReshapeFunc(window);
        glClearColor(1,1,1,1);
        glutMainLoop();
        return 0;      
}
