#include <GL/glut.h>
#include <stdio.h>
 
float x_position =0;
static float speed = 0.1f;

void mudarSinal(){
	speed = speed*-1;
}

void criarQuadrado(){
	glBegin(GL_QUADS);
                glVertex2f(-10,-10);
                glVertex2f(10,-10);
                glVertex2f(10,10);
                glVertex2f(-10,10);
        glEnd();
}

void movimentarQuadrado(){
	glClear(GL_COLOR_BUFFER_BIT);
    glMatrixMode(GL_MODELVIEW);
    glLoadIdentity();
    glColor3f(1,0,0);
    glTranslatef(x_position,0,0);
    criarQuadrado();
    glutSwapBuffers();
}
 
void timer(int time){
	if(x_position >= 10){
	mudarSinal();
	x_position += speed;
	glutPostRedisplay();
    glutTimerFunc(1000/60, timer, 1);
	}
	else if(x_position <= -10){
	mudarSinal();
	x_position += speed;
	glutPostRedisplay();
    glutTimerFunc(1000/60, timer, 1);
    }
    else{
   	x_position += speed; 
    glutPostRedisplay();
    glutTimerFunc(1000/60, timer, 1);
    }
}


 
void window(GLsizei w, GLsizei h){
        GLsizei largura, altura;
        if(h==0)h=1;
       
        largura = w;
        altura = h;
       
        glViewport(0,0,largura,altura);
       
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
       
        if(largura <=altura){
                gluOrtho2D(-20,20,-20*altura/largura,20*altura/largura);
        }else{
                gluOrtho2D(-20*largura/altura, 20*largura/altura, -20,20);
        }
}
 

int main(void){
        glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
        glutInitWindowPosition(10,10);
        glutInitWindowSize(450,450);
        glutCreateWindow("QUADRADOMOVIMENTO");
        glutDisplayFunc(movimentarQuadrado);
        glutTimerFunc(0, timer, 1);
        glutReshapeFunc(window);
        glClearColor(1,1,1,1);
        glutMainLoop();
        return 0;      
}
