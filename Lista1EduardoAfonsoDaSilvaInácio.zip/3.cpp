#include <GL/glut.h>
 

float y_position =0;
float speed = 0.5f;
 
void criarQuadrado(){
	glBegin(GL_QUADS);
                glVertex2f(-10,-10);
                glVertex2f(10,-10);
                glVertex2f(10,10);
                glVertex2f(-10,10);
        glEnd();
} 

void quadradoTranslacao(){
        glClear(GL_COLOR_BUFFER_BIT);
        glMatrixMode(GL_MODELVIEW);
        glLoadIdentity();
        glColor3f(1,0,0);
        glTranslatef(0,y_position,0);
        criarQuadrado();
        glutSwapBuffers();
}
 
 
void window(GLsizei w, GLsizei h){
        GLsizei largura, altura;
        if(h==0)h=1;
       
        largura = w;
        altura = h;
       
        glViewport(0,0,largura,altura);
       
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
       
        if(largura <=altura){
                gluOrtho2D(-20,20,-20*altura/largura,20*altura/largura);
        }else{
                gluOrtho2D(-20*largura/altura, 20*largura/altura, -20,20);
        }
}
 
void keyboard(unsigned char key, int x, int y){
        if(key == 27)
                exit(0);
       
        if(key == 32)
                y_position += speed;
               
        glutPostRedisplay();
}
 
int main(void){
        glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
        glutInitWindowPosition(10,10);
        glutInitWindowSize(450,450);
        glutCreateWindow("QUADRADOTRANSLACAO");
        glutDisplayFunc(quadradoTranslacao);
        glutKeyboardFunc(keyboard);
        glutReshapeFunc(window);
        glClearColor(1,1,1,1);
        glutMainLoop();
        return 0;      
}
