#include <GL/glut.h>
#include <math.h>

float theta;
int i;

void circulo(float raio){
	glBegin(GL_POLYGON);
     for(i=0;i<360;i++){
     	theta = i*3.142/180;
     	glVertex2f(raio*cos(theta),raio*sin(theta));
     }
glEnd();
}

void display()
{
glClear(GL_COLOR_BUFFER_BIT);
glColor3f(0,0,0.2);
glLineWidth(2);
circulo(10.0f);
glColor3f(0,0,0.7);
glLineWidth(2);
circulo(7.5f);
glColor3f(0,0,0.2);
glLineWidth(2);
circulo(5.0f);
glColor3f(1,1,1);
glLineWidth(2);
circulo(2.0f);
glutSwapBuffers();
}

void window(GLsizei w, GLsizei h){
        GLsizei largura, altura;
        if(h==0)h=1;
       
        largura = w;
        altura = h;
       
        glViewport(0,0,largura,altura);
       
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
       
        if(largura <=altura){
                gluOrtho2D(-20,20,-20*altura/largura,20*altura/largura);
        }else{
                gluOrtho2D(-20*largura/altura, 20*largura/altura, -20,20);
        }
}

int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
glutInitWindowSize(450,450);
glutCreateWindow("CIRCULO");
glutDisplayFunc(display);
glutReshapeFunc(window);
glClearColor(1,1,1,1);
glutMainLoop();
return 0;
}
