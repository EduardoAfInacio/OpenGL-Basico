#include <GL/glut.h>

void criarObjeto1(){
	
glBegin(GL_QUADS);
glVertex2f(-5,-4);
glVertex2f(-10,0);
glVertex2f(10,0);
glVertex2f(5,-4);
glEnd();
}

void criarObjeto2(){
	
glBegin(GL_QUADS);
glVertex2f(-2,0);
glVertex2f(-2,12);
glVertex2f(-1,12);
glVertex2f(-1,0);
glEnd();
}

void criarObjeto3(){
	
glBegin(GL_QUADS);
glVertex2f(-2,12);
glVertex2f(-2,13.5);
glVertex2f(2,13.5);
glVertex2f(2,12);
glEnd();

}

void criarObjeto4(){
	
glBegin(GL_TRIANGLES);
glVertex2f(-2,12);
glVertex2f(-2,2);
glVertex2f(-6,2);
glEnd();

}

void criarObjeto5(){
glBegin(GL_TRIANGLES);
glVertex2f(-1,12);
glVertex2f(-1,2);
glVertex2f(6,2);
glEnd();
}

void display()
{
glClear(GL_COLOR_BUFFER_BIT);

glColor3f(1,0,0);
criarObjeto1();
glColor3f(0.6,0.29803921568,0);
criarObjeto2();
glColor3f(0,0,1);
criarObjeto3();
glColor3f(0.74117647058,0.74117647058,0.74117647058);
criarObjeto4();
glColor3f(0.74117647058,0.74117647058,0.74117647058);
criarObjeto5();
glFlush();
glutSwapBuffers();
}

void window(GLsizei w, GLsizei h){
        GLsizei largura, altura;
        if(h==0)h=1;
       
        largura = w;
        altura = h;
       
        glViewport(0,0,largura,altura);
       
        glMatrixMode(GL_PROJECTION);
        glLoadIdentity();
       
        if(largura <=altura){
                gluOrtho2D(-20,20,-20*altura/largura,20*altura/largura);
        }else{
                gluOrtho2D(-20*largura/altura, 20*largura/altura, -20,20);
        }
}

int main(int argc, char** argv)
{
glutInit(&argc, argv);
glutInitDisplayMode(GLUT_DOUBLE | GLUT_RGBA);
glutInitWindowSize(450,450);
glutCreateWindow("BARCO");
glutDisplayFunc(display);
glutReshapeFunc(window);
glClearColor(1,1,1,1);
glutMainLoop();
return 0;
}
